<?xml version="1.0"encoding="utf-8"?>
<!--
        ~Copyright 2018The Android Open Source Project
        ~
        ~Licensed under the Apache License,Version2.0(the"License");
        ~you may not use this file except in compliance with the License.
        ~You may obtain a copy of the License at
        ~
        ~https://www.apache.org/licenses/LICENSE-2.0
        ~
        ~Unless required by applicable law or agreed to in writing,s